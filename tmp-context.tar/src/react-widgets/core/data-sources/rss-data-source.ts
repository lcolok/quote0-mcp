/**
 * RSS数据源模块
 * 支持多个预设RSS订阅源的管理和获取
 */

import { BaseDataSourceModule } from './base-data-source.js';
import { 
  RawDataItem, 
  DataSourceParams, 
  DataSourceParamDefinition,
  DataSourceHealthStatus 
} from '../modular-architecture.js';

interface RSSSource {
  name: string;
  url: string;
  category: string;
  description: string;
}

export class RSSDataSourceModule extends BaseDataSourceModule {
  name = 'RSS数据源';
  version = '1.0.0';
  description = '从多个RSS订阅源获取新闻数据';
  
  // 预设的RSS订阅源
  private rssFeeds: Record<string, RSSSource> = {
    // 科技资讯
    solidot: {
      name: 'Solidot',
      url: 'https://www.solidot.org/index.rss',
      category: 'technology',
      description: '奇客的资讯，重要的东西'
    },
    sspai: {
      name: '少数派',
      url: 'https://sspai.com/feed',
      category: 'technology',
      description: '高效工作，品质生活'
    },
    'cnbeta': {
      name: 'cnBeta',
      url: 'https://www.cnbeta.com/backend.php',
      category: 'technology', 
      description: '中文业界资讯站'
    },
    'pingwest': {
      name: 'PingWest',
      url: 'https://www.pingwest.com/feed',
      category: 'technology',
      description: '科技媒体平台'
    },
    'techcrunch': {
      name: 'TechCrunch',
      url: 'https://feeds.feedburner.com/TechCrunch',
      category: 'technology',
      description: '全球科技创业资讯'
    },
    'arstechnica': {
      name: 'Ars Technica',
      url: 'http://feeds.arstechnica.com/arstechnica/index',
      category: 'technology',
      description: '深度科技分析'
    },
    
    // 商业财经
    '36kr': {
      name: '36氪',
      url: 'https://36kr.com/feed',
      category: 'business',
      description: '创投媒体平台'
    },
    'reuters-tech': {
      name: 'Reuters Tech',
      url: 'https://feeds.reuters.com/reuters/technologyNews',
      category: 'business',
      description: '路透社科技新闻'
    },
    
    // 设计创意
    'designer-news': {
      name: 'Designer News',
      url: 'https://www.designernews.co/feeds/stories',
      category: 'design',
      description: '设计师资讯平台'
    },
    
    // 开发者
    'github-trending': {
      name: 'GitHub Trending',
      url: 'https://rsshub.app/github/trending/daily',
      category: 'programming',
      description: 'GitHub热门项目'
    },
    'dev-to': {
      name: 'DEV Community',
      url: 'https://dev.to/feed',
      category: 'programming',
      description: '开发者技术分享'
    }
  };
  
  async fetchRawData(params: DataSourceParams): Promise<RawDataItem[]> {
    const Parser = (await import('rss-parser')).default;
    const parser = new Parser({
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; ModularNewsWidget/1.0)'
      }
    });
    
    // 支持通过source参数选择预设订阅源，或直接指定url
    let rssUrl: string;
    let sourceName: string;
    let defaultCategory: string;
    
    if (params.source && this.rssFeeds[params.source]) {
      const feed = this.rssFeeds[params.source];
      rssUrl = feed.url;
      sourceName = feed.name;
      defaultCategory = feed.category;
    } else {
      rssUrl = params.url || this.rssFeeds.solidot.url;
      sourceName = 'RSS源';
      defaultCategory = '新闻';
    }
    
    const count = params.count || 10;
    const startIndex = params.startIndex || 0;
    const category = params.category || defaultCategory;
    
    console.log(`📡 RSS数据源获取: ${sourceName} (${rssUrl}) 从${startIndex}开始，获取${count}条`);
    
    try {
      const feed = await parser.parseURL(rssUrl);
      
      if (!feed.items || feed.items.length === 0) {
        throw new Error(`RSS源 ${sourceName} 没有找到新闻条目`);
      }
      
      const endIndex = Math.min(startIndex + count, feed.items.length);
      const selectedItems = feed.items.slice(startIndex, endIndex);
      
      const rawDataItems: RawDataItem[] = selectedItems.map((item, index) => ({
        id: `rss_${params.source || 'custom'}_${startIndex + index}_${Date.now()}`,
        title: item.title || '无标题',
        content: this.cleanContent(item.contentSnippet || item.content || item.description || ''),
        source: feed.title || sourceName,
        publishTime: item.pubDate || new Date().toISOString(),
        link: item.link,
        category,
        metadata: {
          rssUrl,
          rssSource: params.source || 'custom',
          originalIndex: startIndex + index,
          guid: item.guid
        }
      }));
      
      console.log(`✅ RSS数据源获取成功: ${rawDataItems.length}条数据 来自 ${sourceName}`);
      return rawDataItems;
      
    } catch (error) {
      console.error(`RSS数据源获取失败 (${sourceName}):`, error);
      throw new Error(`RSS数据获取失败 (${sourceName}): ${error instanceof Error ? error.message : '未知错误'}`);
    }
  }
  
  getSupportedParams(): DataSourceParamDefinition[] {
    return [
      {
        name: 'source',
        type: 'string',
        required: false,
        description: '预设RSS订阅源',
        choices: Object.keys(this.rssFeeds),
        defaultValue: 'solidot'
      },
      {
        name: 'url',
        type: 'string',
        required: false,
        description: '自定义RSS订阅地址（不使用预设源时）'
      },
      {
        name: 'count',
        type: 'number',
        required: false,
        defaultValue: 10,
        description: '获取条目数量',
        validation: (value: number) => value > 0 && value <= 50
      },
      {
        name: 'startIndex',
        type: 'number',
        required: false,
        defaultValue: 0,
        description: '开始索引',
        validation: (value: number) => value >= 0
      },
      {
        name: 'category',
        type: 'string',
        required: false,
        description: '覆盖默认新闻分类'
      }
    ];
  }
  
  private cleanContent(content: string): string {
    // 清理HTML标签和多余空白
    return content
      .replace(/<[^>]*>/g, '')
      .replace(/\\s+/g, ' ')
      .trim();
  }
  
  /**
   * 获取所有预设RSS订阅源信息
   */
  getAvailableFeeds(): Record<string, RSSSource> {
    return { ...this.rssFeeds };
  }
  
  /**
   * 添加新的RSS订阅源
   */
  addFeed(key: string, source: RSSSource): void {
    this.rssFeeds[key] = source;
  }
  
  async getHealthStatus(): Promise<DataSourceHealthStatus> {
    const startTime = Date.now();
    
    try {
      // 测试默认的Solidot RSS源
      const testData = await this.fetchRawData({ 
        source: 'solidot', 
        count: 1, 
        startIndex: 0 
      });
      
      const responseTime = Date.now() - startTime;
      
      return {
        healthy: true,
        message: `RSS数据源正常运行 (${Object.keys(this.rssFeeds).length}个预设源)`,
        lastChecked: new Date().toISOString(),
        responseTime,
        dataQuality: testData.length > 0 ? 100 : 50,
        additionalInfo: {
          availableFeeds: Object.keys(this.rssFeeds).length,
          presetSources: Object.keys(this.rssFeeds),
          testSource: 'solidot'
        }
      };
      
    } catch (error) {
      return {
        healthy: false,
        message: `RSS数据源异常: ${error instanceof Error ? error.message : '未知错误'}`,
        lastChecked: new Date().toISOString(),
        responseTime: Date.now() - startTime,
        dataQuality: 0
      };
    }
  }
}