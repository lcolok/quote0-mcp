/**
 * AX框架训练数据 - 新闻内容优化
 * 用于快速训练场景的基础数据集
 */

export const trainingData = [
  {
    newsContent: "研究称闻气味能增加大脑灰质。根据发表在《Brain Research Bulletin》期刊上的一项研究，日本科学家报告称长时间闻香水能增加大脑灰质。",
    expectedTitle: "闻香水增大脑灰质",
    expectedSummary: "日本研究发现，长期闻玫瑰香油能增加大脑灰质，可能对痴呆症治疗有重要意义。"
  },
  {
    newsContent: "Adobe Reader 安装程序的大小过去几年大幅膨胀，原因当然是和所有科技公司一样，要在其产品中集成炙手可热的 AI。Adobe Reader 25.1 版本容量接近 700MB。",
    expectedTitle: "Adobe Reader膨胀至700MB",
    expectedSummary: "Adobe Reader因集成AI功能，安装包从100MB膨胀至接近700MB，而轻量替代品SumatraPDF仅10MB以内。"
  },
  {
    newsContent: "日本气象厅周一发布消息，今年夏天平均气温较往年高出 2.36 度，创 1898 年开始统计以来新高。日本已连续 3 年经历最炎热夏季。",
    expectedTitle: "日本气温创126年新高",
    expectedSummary: "日本今夏平均气温比往年高2.36°C，创1898年来新高，连续3年成为最热夏季，全国132个气象站创纪录。"
  },
  {
    newsContent: "建造在砂质土壤上的非洲城市在裂开。气候变化导致的极端天气正在影响城市基础设施的稳定性，特别是那些建在不稳定地基上的城市。",
    expectedTitle: "非洲城市因气候裂开",
    expectedSummary: "气候变化导致极端天气影响城市基础设施，建在砂质土壤上的非洲城市出现裂开现象，地基不稳定问题凸显。"
  },
  {
    newsContent: "SpaceX 星舰进行了第五次试飞，这次测试重点关注着陆系统的改进和燃料效率的优化。测试取得了重要进展。",
    expectedTitle: "星舰五次试飞成功",
    expectedSummary: "SpaceX星舰完成第五次试飞，重点测试着陆系统改进和燃料效率优化，在技术发展上取得重要进展。"
  }
];